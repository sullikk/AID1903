from day4.test import *
import time

st = time.time()

for i in range(10):
    # count(1,1)
    io()

print("Single IO:",time.time() - st)





